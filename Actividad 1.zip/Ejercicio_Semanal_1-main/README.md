# Ejercicio_Semanal_1
Primer ejercicio semanal de Estructura de Datos
