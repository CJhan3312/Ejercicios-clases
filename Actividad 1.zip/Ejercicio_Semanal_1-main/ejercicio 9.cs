/*Edad Humana Perro*/

{
def calcular_edad_perro(la edad_persona);
      if edad_persona <= 2;
         return edad_persona * 10.5
    else;
         return 21 + (edad_persona - 2) * 4

int(input("Digite la edad de años de la persona:"))      

if edad_persona > 0; 
    resultado = calcular_edad_perro(edad_persona)
    print(f'La cantidad que corresponde en la vida de un perro es {resultado}');

}




